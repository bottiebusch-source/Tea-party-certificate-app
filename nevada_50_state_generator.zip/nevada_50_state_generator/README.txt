50-STATE CERTIFICATE & DISCLOSURE GENERATOR — PROTOTYPE v0.2

START
1. Extract the ZIP file.
2. Open index.html in a modern browser (Chrome, Edge, Firefox, or Safari). No server or install is required.
3. Select Nevada, edit business details, then use Print / Save PDF.
4. For duplex printing, print both pages and select double-sided / flip on long edge as appropriate for your printer.

WHAT WORKS
- Selectable list of all 50 states.
- Editable business name, owner/representative, draft date, and internal document ID.
- Ornate navy/cream front and two-column parchment back.
- Nevada initial source-linked business and alcohol disclosures.
- Other states are explicitly marked research-required, not falsely represented as verified.
- Print stylesheet for PDF/physical printing.

IMPORTANT LIMITATIONS
- This is a private document generator, not a state-issued certificate, license, deed, registration, or proof of ownership.
- Nevada profile was expanded on October 22, 2026 with links to official business-license, statute, regulation, and federal TTB sources. It remains a summary, not a complete legal review. Confirm the exact activity and location with state, county, city, and federal regulators.
- Published fees and penalty references can change; verify current fees and requirements on the linked official pages before use. The app does not automatically fetch or update legal changes.
- 49 other state profiles are template shells pending official-source research and legal review.
- The date in the document is a draft preparation date, not a legal effective date. Legal effective dates must be added per verified source before production.

NEVADA OFFICIAL SOURCES
Nevada Secretary of State — State Business License FAQ:
https://nvsos.gov/sos/licensing/state-business-license/state-business-license-faq
Nevada Revised Statutes, Chapter 76:
https://www.leg.state.nv.us/Division/Legal/Lawlibrary/NRS/NRS-076.html
Nevada Secretary of State — Business:
https://nvsos.gov/sos/businesses
Nevada Revised Statutes, Chapter 369:
https://www.leg.state.nv.us/nrs/NRS-369.html
Nevada Department of Taxation — Liquor General Information:
https://tax.nv.gov/liquor-general-information/
Nevada Administrative Code, Chapter 369:
https://www.leg.state.nv.us/Nac/NAC-369.html

Federal alcohol reference (TTB):
https://www.ttb.gov/

VERSION NOTES
v0.2 — Expanded Nevada business-license and alcohol-law disclosures; added explicit statutory references to NRS 369.015, 369.320, and 369.490; expanded source links and review-date language. JavaScript syntax checked.


VERSION 0.3 UPDATE — 22 October 2026
- Refined Nevada alcohol disclosures to point to NRS 369.180, 369.320, 369.330 onward, and 369.490.
- Corrected and expanded official-source descriptions.
- Added the Nevada Chapter 369 compilation revision date shown on the official legislature page (April 15, 2026).
- Preserved draft status. This is not legal advice or an issued state document.
- The other 49 states remain research-required shells.


VERSION 0.4 UPDATE — 22 October 2026
- Added the official NAC Chapter 369 revision date shown as August 26, 2026.
- Refined source review notes and the Nevada profile status label.
- The app still treats all states other than Nevada as research-required shells.
